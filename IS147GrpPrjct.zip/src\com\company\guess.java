package com.company;


        public class guess {

            private String username;

            public guess( String nameParameter ) {
                this.username = nameParameter;
            }
            public String toString() {
                return "Hello " + this.username + " these are some of your classmate's GPAs ";
            }


    }

