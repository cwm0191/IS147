package com.company;


public class professor extends Main {


    private String username;

    public professor( String nameParameter ) {
        this.username = nameParameter;
    }
    public String toString() {
        return "Make sure you fill out a great course eval for " + this.username + " then! he must truly be the best";


    }
    }
