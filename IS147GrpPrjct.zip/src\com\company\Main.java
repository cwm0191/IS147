//IS 147 GPA Calculator Group C
package com.company;
import java.util.Scanner;
import java.text.DecimalFormat;

public class Main {

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        String name;
        System.out.print("What is your Name?: ");
        name = in.nextLine();
        guess testVar = new guess(name);
        System.out.println( testVar );


        Scanner input = new Scanner (System.in);
        DecimalFormat df = new DecimalFormat("#, ###, ##0.0");
        String grade = "";
        double credit1;
        double credit2;
        double credit3;
        double credit4;
        double credit5;
        double credit6;
        double gradeValue=0;
        double totPtsClass1=0;
        double totPtsClass2=0;
        double totPtsClass3=0;
        double totPtsClass4=0;
        double totPtsClass5=0;
        double totPtsClass6=0;
        double totPts=0;
        double totalCredits= 0;
        double gpa;


        //Random student GPAs for comparsion
        double student[] = new double[7];
        for (int i = 0; i < 6; i++)
        {
            student[i] = Math.random() * 6;
            System.out.println(df.format(student[i]));
        }


        String prof;
        System.out.print("Who is your favorite professor?: ");
        prof = in.nextLine();
        professor fave = new professor(prof);
        System.out.println( fave );









        System.out.println("Please enter Class#1's credit amount(number)");
        credit1 = input.nextDouble();
        System.out.println("Please enter the grade you received in Class#1 (Capital letters such as A,B,C,D,F)");
        grade = input.next();

        switch (grade) {
            case "A":  gradeValue= 4.00;
                break;
            case "B":  gradeValue = 3.00;
                break;
            case "C":  gradeValue = 2.00;
                break;
            case "D":  gradeValue = 1.00;
                break;
            case "F":  gradeValue = 0;
                break;
            default: grade = "Invalid Grade";
                break;
        }
        totPtsClass1 = gradeValue * credit1;

        System.out.println("Please enter Class#2's credit amount(number)");
        credit2 = input.nextDouble();
        System.out.println("Please enter the grade you recieved in Class#2 (Capital letters such as A,B,C,D,F)");
        grade = input.next();

        if (grade.equals ("A"))
            gradeValue= 4.00;
        else if (grade.equals("B"))
            gradeValue = 3.00;
        else if (grade.equals("C"))
            gradeValue = 2.00;
        else if (grade.equals ("D"))
            gradeValue = 1.00;
        else if (grade.equals ("F"))
            gradeValue = 0;
        else
            System.out.println ("Invalid Grade");

        totPtsClass2 = gradeValue * credit2;

        System.out.println("Please enter Class#3's credit amount(number)");
        credit3 = input.nextDouble();
        System.out.println("Please enter the grade you recieved in Class#3 (Capital letters such as A,B,C,D,F)");
        grade = input.next();

        if (grade.equals ("A"))
            gradeValue= 4.00;
        else if (grade.equals("B"))
            gradeValue = 3.00;
        else if (grade.equals("C"))
            gradeValue = 2.00;
        else if (grade.equals ("D"))
            gradeValue = 1.00;
        else if (grade.equals ("F"))
            gradeValue = 0;
        else
            System.out.println ("Invalid Grade");

        totPtsClass3 = gradeValue * credit3;

        System.out.println("Please enter Class#4's credit amount(number)");
        credit4 = input.nextDouble();
        System.out.println("Please enter the grade you recieved in Class#4 (Capital letters such as A,B,C,D,F)");
        grade = input.next();

        if (grade.equals ("A"))
            gradeValue= 4.00;
        else if (grade.equals("B"))
            gradeValue = 3.00;
        else if (grade.equals("C"))
            gradeValue = 2.00;
        else if (grade.equals ("D"))
            gradeValue = 1.00;
        else if (grade.equals ("F"))
            gradeValue = 0;
        else
            System.out.println ("Invalid Grade");

        totPtsClass4 = gradeValue * credit4;

        System.out.println("Please enter Class#5's credit amount(number)");
        credit5 = input.nextDouble();
        System.out.println("Please enter the grade you recieved in Class#5 (Capital letters such as A,B,C,D,F)");
        grade = input.next();

        if (grade.equals ("A"))
            gradeValue= 4.00;
        else if (grade.equals("B"))
            gradeValue = 3.00;
        else if (grade.equals("C"))
            gradeValue = 2.00;
        else if (grade.equals ("D"))
            gradeValue = 1.00;
        else if (grade.equals ("F"))
            gradeValue = 0;
        else
            System.out.println ("Invalid Grade");

        totPtsClass5 = gradeValue * credit5;

        System.out.println("Please enter Class#6's credit amount(number)");
        credit6 = input.nextDouble();
        System.out.println("Please enter the grade you recieved in Class#6 (Capital letters such as A,B,C,D,F)");
        grade = input.next();

        if (grade.equals ("A"))
            gradeValue= 4.00;
        else if (grade.equals("B"))
            gradeValue = 3.00;
        else if (grade.equals("C"))
            gradeValue = 2.00;
        else if (grade.equals ("D"))
            gradeValue = 1.00;
        else if (grade.equals ("F"))
            gradeValue = 0;
        else
            System.out.println ("Invalid Grade");

        totPtsClass6 = gradeValue * credit6;

        totPts= totPtsClass1+totPtsClass2+totPtsClass3+totPtsClass4+totPtsClass5+totPtsClass6;
        totalCredits = credit1+credit2+credit3+credit4+credit5+credit6;
        gpa= totPts / totalCredits;

        System.out.printf("Your GPA is: %.2f\n", + gpa);


    }
}
